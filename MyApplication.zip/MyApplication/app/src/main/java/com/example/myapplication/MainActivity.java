package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.TextView;

import java.sql.Time;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private Button startbtn;
    private TextView t_d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getTime();

        startbtn=findViewById(R.id.start_button);
        startbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Chronometer c=(Chronometer)findViewById(R.id.timer);
                c.start();


                goInformation(view);
            }
        });

    }

    public void goInformation(View v) {
        Intent i=new Intent(MainActivity.this,InforActivity.class);
        startActivity(i);
    }

    public void getTime(){
        Calendar c=Calendar.getInstance();
        int year=c.get(Calendar.YEAR);
        int month=c.get(Calendar.MONTH)+1;
        int day=c.get(Calendar.DAY_OF_MONTH);
        int hour=c.get(Calendar.HOUR_OF_DAY);
        int minute=c.get(Calendar.MINUTE);
        TextView t_d=(TextView)findViewById(R.id.data_time);
        t_d.setText(day+"/"+month+"/"+year+" "+hour+":"+minute);
    }

}