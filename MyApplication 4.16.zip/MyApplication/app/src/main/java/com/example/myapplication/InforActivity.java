package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Calendar;

public class InforActivity extends AppCompatActivity {

    private Button inforbtn;
    protected static String duration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infor);

        getDuration();

        inforbtn=findViewById(R.id.infor_button);
        inforbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goRecommend(view);
            }
        });

    }

    public void getDuration(){
        TextView t_v=(TextView)findViewById(R.id.duration);
        t_v.setText(duration);
    }

    public void goRecommend(View v) {
        Intent i=new Intent(InforActivity.this,AdviceActivity.class);
        startActivity(i);
    }

}