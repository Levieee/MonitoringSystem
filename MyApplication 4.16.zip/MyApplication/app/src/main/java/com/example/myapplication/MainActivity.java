package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.TextView;

import java.sql.Time;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity{

    public int flag=0;
    private Chronometer chronometer;
    public long recordingTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getTime();

        chronometer = (Chronometer) findViewById(R.id.timer);

        Button startbtn = (Button) findViewById(R.id.start_button);
        startbtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if (flag == 0) {
                    //startbtn.setEnabled(false);
                    startbtn.setText("STOP");
                    chronometer.start();
                    flag = 1;
                    Log.i("click_start", String.valueOf(flag));
                }else if(flag==1){
                    //startbtn.setEnabled(true);
                    chronometer.stop();
                    recordingTime = SystemClock.elapsedRealtime() - chronometer.getBase();
                    chronometer.setBase(SystemClock.elapsedRealtime());
                    transDuration();
                    goInformation(view);
                    flag = 0;
                    Log.i("click_stop", String.valueOf(flag));
                    Log.i("record time:", String.valueOf(recordingTime));
                }
            }
        });
    }

    public void goInformation(View v) {
        Intent i=new Intent(MainActivity.this,InforActivity.class);
        startActivity(i);
    }

    public void getTime(){
        Calendar c=Calendar.getInstance();
        int year=c.get(Calendar.YEAR);
        int month=c.get(Calendar.MONTH)+1;
        int day=c.get(Calendar.DAY_OF_MONTH);
        int hour=c.get(Calendar.HOUR_OF_DAY);
        int minute=c.get(Calendar.MINUTE);
        TextView t_d=(TextView)findViewById(R.id.data_time);
        t_d.setText(day+"/"+month+"/"+year+" "+hour+":"+minute);
    }

    public void transDuration(){
        Intent i=new Intent(MainActivity.this,InforActivity.class);
        InforActivity.duration=String.valueOf(recordingTime/60000);
        startActivity(i);
    }

}